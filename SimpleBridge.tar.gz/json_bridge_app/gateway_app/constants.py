CONSTANTS = {
    "gateway_group_name": "gateway",
    "json_error": "Invalid JSON",
    "invalid_method": "Method not allowed",
    "test_case_key": "test",
    "test_case_value": "testValue",
    "app_name": "gateway_app",

}
